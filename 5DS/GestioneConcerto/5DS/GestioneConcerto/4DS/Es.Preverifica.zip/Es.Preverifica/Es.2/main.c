#include <stdio.h>
#include <stdlib.h>

int sottraiElemento(int* arr, int lun){
	int num;
	int i;
	
	for(i = 0; i < (lun - 1); i++){
		num = arr[i] - arr[i+1];
		if(num < 0){
			return -1;
		}
		printf("\nDifferenza tra %d e %d: %d", arr[i], arr[i+1], num);
	}
	return 0;
}

int main(int argc, char *argv[]) {
	int num;
	int lun;
	int i;
	
	printf("Quanti valori vuoi scrivere?");
	scanf("\n%d", &lun);
	
	int* arr = malloc(lun * sizeof(int));
	
	for(i = 0; i < lun; i++){
		printf("Valore: ");
		scanf("%d", &arr[i]);
	}
	
	num = sottraiElemento(arr, lun);
	if(num == -1){
		printf("\nProcesso interrotto: Valore negativo!");
	}else{
		printf("\nProcesso terminato con successo!");
	}
	return 0;
}
