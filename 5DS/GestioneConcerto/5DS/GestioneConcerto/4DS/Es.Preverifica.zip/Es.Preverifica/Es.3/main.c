#include <stdio.h>
#include <stdlib.h>

struct Utente{
	char nome[20];
	char cognome[20];
	int eta;
};

void inserisci(struct Utente* users, int* lun){
	*lun += 1;
	*users = (struct Utente)realloc(users, lun * sizeof(struct Utente));
	
	printf("Inserisci il nome: ");
	scanf("%20s", users[lun-1]->nome);
	
	printf("Inserisci il cognome: ");
	scanf("%20s", users[lun-1]->cognome);
	
	printf("Inserisci l'eta': ");
	scanf("%d", &users[lun-1]->eta);
}

struct Utente personaGrande(struct Utente* users, int* lun){
	
}

int main(int argc, char *argv[]) {
	int scelta;
	int lun = 0;
	struct Utente* users = NULL;
	
	do{
		printf("1) Inserisci un utente \n2) Trova utente con et� maggiore");
		scanf("%d", &scelta);
		switch(scelta) {
			case 0:
				printf("Arrivederci!");
				break;
			case 1:
				inserisci(users, &lun);
			default:
				printf("Scelta errata!");
		}
	}while(scelta == 0);
	return 0;
}
