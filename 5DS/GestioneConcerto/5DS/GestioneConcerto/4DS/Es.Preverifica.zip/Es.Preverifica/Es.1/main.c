#include <stdio.h>
#include <stdlib.h>

void raddoppiaArray(int* arr, int lun){
	int i;
	for(i = 0; i < lun; i++){
		arr[i] = arr[i]*2;
	}
}

int main(int argc, char *argv[]) {
	int lun;
	int i;

	printf("Quanti valori vuoi scrivere?");
	scanf("\n%d", &lun);
	
	int arr[lun];
	
	for(i = 0; i < lun; i++){
		printf("Valore: ");
		scanf("%d", &arr[i]);
	}
	
	printf("Array iniziale: ");
	for(i = 0; i < lun; i++){
		printf("\n%d", arr[i]);
	}
	
	raddoppiaArray(arr, lun);
	
	printf("\nArray raddoppiato: ");
	for(i = 0; i < lun; i++){
		printf("\n%d", arr[i]);
	}
	
	return 0;
}
